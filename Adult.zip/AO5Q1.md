# Exploratory Data Analysis and Model Building - Adult-Income-Dataset
Data Description :

An individual’s annual income results from various factors. Intuitively, it is influenced by the individual’s education level, age, gender, occupation

Kaggle URL to Download Dataset: https://www.kaggle.com/datasets/wenruliu/adult-income-dataset

What is a Term Adult?

An adult is a mature, fully developed person. Adult has reached the age when they are legally responsible for their actions.



# 1. Importing the libraries 



```python
# Importing the libraries 

import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt

# Ignore harmless warnings 

import warnings 
warnings.filterwarnings("ignore")

# Set to display all the columns in dataset

pd.set_option("display.max_columns", None)

# Import psql to run queries 

import pandasql as psql

import seaborn as sns
```

# 2. Reading the Adult-Income data


```python
adult_inc = pd.read_csv(r"C:\Users\Rashee\Downloads\adult2.csv", encoding="ISO-8859-1", header=0)
adult_inc_bk = pd.read_csv(r"C:\Users\Rashee\Downloads\adult2.csv", encoding="ISO-8859-1", header=0)
adult_inc.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>workclass</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>educational-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>race</th>
      <th>gender</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
      <th>native-country</th>
      <th>income</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>25</td>
      <td>Private</td>
      <td>226802</td>
      <td>11th</td>
      <td>7</td>
      <td>Never-married</td>
      <td>Machine-op-inspct</td>
      <td>Own-child</td>
      <td>Black</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38</td>
      <td>Private</td>
      <td>89814</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Married-civ-spouse</td>
      <td>Farming-fishing</td>
      <td>Husband</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>Local-gov</td>
      <td>336951</td>
      <td>Assoc-acdm</td>
      <td>12</td>
      <td>Married-civ-spouse</td>
      <td>Protective-serv</td>
      <td>Husband</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
    </tr>
    <tr>
      <th>3</th>
      <td>44</td>
      <td>Private</td>
      <td>160323</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Married-civ-spouse</td>
      <td>Machine-op-inspct</td>
      <td>Husband</td>
      <td>Black</td>
      <td>Male</td>
      <td>7688</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
    </tr>
    <tr>
      <th>4</th>
      <td>18</td>
      <td>?</td>
      <td>103497</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Never-married</td>
      <td>?</td>
      <td>Own-child</td>
      <td>White</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>30</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
    </tr>
  </tbody>
</table>
</div>



# 3. Shape of Adult-income data



```python
adult_inc.shape
```




    (48842, 15)



# Display the Adult-Income dataset information


```python
adult_inc.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 48842 entries, 0 to 48841
    Data columns (total 15 columns):
     #   Column           Non-Null Count  Dtype 
    ---  ------           --------------  ----- 
     0   age              48842 non-null  int64 
     1   workclass        48842 non-null  object
     2   fnlwgt           48842 non-null  int64 
     3   education        48842 non-null  object
     4   educational-num  48842 non-null  int64 
     5   marital-status   48842 non-null  object
     6   occupation       48842 non-null  object
     7   relationship     48842 non-null  object
     8   race             48842 non-null  object
     9   gender           48842 non-null  object
     10  capital-gain     48842 non-null  int64 
     11  capital-loss     48842 non-null  int64 
     12  hours-per-week   48842 non-null  int64 
     13  native-country   48842 non-null  object
     14  income           48842 non-null  object
    dtypes: int64(6), object(9)
    memory usage: 5.6+ MB
    


```python
#Renaming columns

adult_inc.rename({"education-num":"educational_num","marital-status":"marital-status","sex":"gender","capital-gain":"capital_gain","capital-loss":"capital_loss",
         "hours-per-week":"hours_per_week","native-country":"native_country"},axis=1,inplace=True)
```

# Data Cleaning


```python
#Finding the special characters in the data frame 
adult_inc.isin(['?']).sum(axis=0)

```




    age                   0
    workclass          2799
    fnlwgt                0
    education             0
    educational-num       0
    marital-status        0
    occupation         2809
    relationship          0
    race                  0
    gender                0
    capital_gain          0
    capital_loss          0
    hours_per_week        0
    native_country      857
    income                0
    dtype: int64




```python
cols=['workclass1','occupation','native_country']
```


```python
adult_inc['workclass1']=adult_inc['workclass'].replace('?',adult_inc['workclass'].mode()[0])
del adult_inc['workclass']
```


```python
#Filling missing values using SimpleImputer

from sklearn.impute import SimpleImputer

imputer_si = SimpleImputer(missing_values=np.nan,strategy='most_frequent')
for i in cols:
    adult_inc[i] = imputer_si.fit_transform(adult_inc[[i]])
```


```python
adult_inc['occupation']=adult_inc['occupation'].replace('?',adult_inc['occupation'].mode()[0])
adult_inc['native_country']=adult_inc['native_country'].replace('?',adult_inc['native_country'].mode()[0])
```


```python
#checking the special characters in the data frame 
adult_inc.isin(['?']).sum(axis=0)
```




    age                0
    fnlwgt             0
    education          0
    educational-num    0
    marital-status     0
    occupation         0
    relationship       0
    race               0
    gender             0
    capital_gain       0
    capital_loss       0
    hours_per_week     0
    native_country     0
    income             0
    workclass1         0
    dtype: int64



# Find Missing Values



```python
adult_inc.isnull().sum()
```




    age                0
    fnlwgt             0
    education          0
    educational-num    0
    marital-status     0
    occupation         0
    relationship       0
    race               0
    gender             0
    capital_gain       0
    capital_loss       0
    hours_per_week     0
    native_country     0
    income             0
    workclass1         0
    dtype: int64



# Find Features with One Value


```python
adult_inc.nunique()
```




    age                   74
    fnlwgt             28523
    education             16
    educational-num       16
    marital-status         7
    occupation            14
    relationship           6
    race                   5
    gender                 2
    capital_gain         123
    capital_loss          99
    hours_per_week        96
    native_country        41
    income                 2
    workclass1             8
    dtype: int64



# Check the Data set is balanced or not based on target values in classification


```python
 adult_inc['income'].value_counts()
```




    <=50K    37155
    >50K     11687
    Name: income, dtype: int64




```python
# Count the target or dependent variable by '0', '1' & their proportion (>= 10 : 1, then the dataset is imbalance dataset)

class_count = adult_inc['income'].value_counts()
print('Class 0:', class_count[0])
print('Class 1:', class_count[1])
print('Proportion:', round(class_count[0] / class_count[1], 2), ': 1')
print('Total  Records:', len(adult_inc))
```

    Class 0: 37155
    Class 1: 11687
    Proportion: 3.18 : 1
    Total  Records: 48842
    

# Explore the Categorical Features


```python
categorical_features=[feature for feature in adult_inc.columns if ((adult_inc[feature].dtypes=='O') & (feature not in ['income']))]
categorical_features
```




    ['education',
     'marital-status',
     'occupation',
     'relationship',
     'race',
     'gender',
     'native_country',
     'workclass1']




```python
for feature in categorical_features:
    print('The feature is {} and number of categories are {}'.format(feature,len(adult_inc[feature].unique())))

```

    The feature is education and number of categories are 16
    The feature is marital-status and number of categories are 7
    The feature is occupation and number of categories are 14
    The feature is relationship and number of categories are 6
    The feature is race and number of categories are 5
    The feature is gender and number of categories are 2
    The feature is native_country and number of categories are 41
    The feature is workclass1 and number of categories are 8
    

# Find Categorical Feature Distribution


```python
plt.figure(figsize=(15,80),facecolor='white')
plotnumber=1
for categorical_feature in categorical_features:
    ax=plt.subplot(12,3,plotnumber)
    sns.countplot(y=categorical_feature,data=adult_inc)
    plt.xlabel(categorical_feature)
    plt.ylabel(categorical_feature)
    plotnumber+=1
plt.show()
```


    
![png](output_28_0.png)
    


# Explore the Correlation between numerical features


```python
adult_inc.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fnlwgt</th>
      <th>educational-num</th>
      <th>capital_gain</th>
      <th>capital_loss</th>
      <th>hours_per_week</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>age</th>
      <td>1.000000</td>
      <td>-0.076628</td>
      <td>0.030940</td>
      <td>0.077229</td>
      <td>0.056944</td>
      <td>0.071558</td>
    </tr>
    <tr>
      <th>fnlwgt</th>
      <td>-0.076628</td>
      <td>1.000000</td>
      <td>-0.038761</td>
      <td>-0.003706</td>
      <td>-0.004366</td>
      <td>-0.013519</td>
    </tr>
    <tr>
      <th>educational-num</th>
      <td>0.030940</td>
      <td>-0.038761</td>
      <td>1.000000</td>
      <td>0.125146</td>
      <td>0.080972</td>
      <td>0.143689</td>
    </tr>
    <tr>
      <th>capital_gain</th>
      <td>0.077229</td>
      <td>-0.003706</td>
      <td>0.125146</td>
      <td>1.000000</td>
      <td>-0.031441</td>
      <td>0.082157</td>
    </tr>
    <tr>
      <th>capital_loss</th>
      <td>0.056944</td>
      <td>-0.004366</td>
      <td>0.080972</td>
      <td>-0.031441</td>
      <td>1.000000</td>
      <td>0.054467</td>
    </tr>
    <tr>
      <th>hours_per_week</th>
      <td>0.071558</td>
      <td>-0.013519</td>
      <td>0.143689</td>
      <td>0.082157</td>
      <td>0.054467</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
## Checking for correlation
cor_mat=adult_inc.corr()
fig = plt.figure(figsize=(15,7))
sns.heatmap(cor_mat,annot=True)
```




    <AxesSubplot:>




    
![png](output_31_1.png)
    



```python
# Use LabelEncoder to handle categorical data

from sklearn.preprocessing import LabelEncoder

LE = LabelEncoder()
for i in adult_inc.columns:
    if adult_inc[i].dtype=='object':
        adult_inc[i] = LE.fit_transform(adult_inc[[i]])
```


```python
adult_inc.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>educational-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>race</th>
      <th>gender</th>
      <th>capital_gain</th>
      <th>capital_loss</th>
      <th>hours_per_week</th>
      <th>native_country</th>
      <th>income</th>
      <th>workclass1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>25</td>
      <td>226802</td>
      <td>1</td>
      <td>7</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38</td>
      <td>89814</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>28</td>
      <td>336951</td>
      <td>7</td>
      <td>12</td>
      <td>2</td>
      <td>10</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>44</td>
      <td>160323</td>
      <td>15</td>
      <td>10</td>
      <td>2</td>
      <td>6</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>7688</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>18</td>
      <td>103497</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>30</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Display the retail dataset information
adult_inc.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 48842 entries, 0 to 48841
    Data columns (total 15 columns):
     #   Column           Non-Null Count  Dtype
    ---  ------           --------------  -----
     0   age              48842 non-null  int64
     1   fnlwgt           48842 non-null  int64
     2   education        48842 non-null  int32
     3   educational-num  48842 non-null  int64
     4   marital-status   48842 non-null  int32
     5   occupation       48842 non-null  int32
     6   relationship     48842 non-null  int32
     7   race             48842 non-null  int32
     8   gender           48842 non-null  int32
     9   capital_gain     48842 non-null  int64
     10  capital_loss     48842 non-null  int64
     11  hours_per_week   48842 non-null  int64
     12  native_country   48842 non-null  int32
     13  income           48842 non-null  int32
     14  workclass1       48842 non-null  int32
    dtypes: int32(9), int64(6)
    memory usage: 3.9 MB
    


```python
adult_inc_dup=adult_inc[adult_inc.duplicated(keep='last')]
adult_inc_dup
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>educational-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>race</th>
      <th>gender</th>
      <th>capital_gain</th>
      <th>capital_loss</th>
      <th>hours_per_week</th>
      <th>native_country</th>
      <th>income</th>
      <th>workclass1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>488</th>
      <td>24</td>
      <td>194630</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>35</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1319</th>
      <td>37</td>
      <td>52870</td>
      <td>9</td>
      <td>13</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1668</th>
      <td>19</td>
      <td>130431</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>36</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1854</th>
      <td>22</td>
      <td>137876</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>10</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>20</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1863</th>
      <td>20</td>
      <td>203353</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3900</th>
      <td>18</td>
      <td>378036</td>
      <td>2</td>
      <td>8</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>38</td>
      <td>0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4152</th>
      <td>17</td>
      <td>153021</td>
      <td>2</td>
      <td>8</td>
      <td>4</td>
      <td>11</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4858</th>
      <td>22</td>
      <td>157332</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5078</th>
      <td>29</td>
      <td>41281</td>
      <td>9</td>
      <td>13</td>
      <td>3</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5782</th>
      <td>21</td>
      <td>301694</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>35</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5907</th>
      <td>41</td>
      <td>116391</td>
      <td>9</td>
      <td>13</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6432</th>
      <td>22</td>
      <td>334593</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>6456</th>
      <td>19</td>
      <td>139466</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>11</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>7021</th>
      <td>30</td>
      <td>180317</td>
      <td>8</td>
      <td>11</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>7350</th>
      <td>30</td>
      <td>111567</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>8116</th>
      <td>19</td>
      <td>167428</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>9249</th>
      <td>29</td>
      <td>36440</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>9825</th>
      <td>25</td>
      <td>112835</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10826</th>
      <td>23</td>
      <td>250630</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>11</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>10923</th>
      <td>23</td>
      <td>239539</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>6</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>29</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>11746</th>
      <td>47</td>
      <td>199058</td>
      <td>15</td>
      <td>10</td>
      <td>2</td>
      <td>9</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>12488</th>
      <td>39</td>
      <td>184659</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>6</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>13504</th>
      <td>45</td>
      <td>82797</td>
      <td>9</td>
      <td>13</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>14153</th>
      <td>21</td>
      <td>243368</td>
      <td>13</td>
      <td>1</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>14308</th>
      <td>25</td>
      <td>308144</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>14398</th>
      <td>19</td>
      <td>318822</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>14487</th>
      <td>31</td>
      <td>228873</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>14838</th>
      <td>43</td>
      <td>195258</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>15323</th>
      <td>23</td>
      <td>107882</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>18584</th>
      <td>90</td>
      <td>52386</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>35</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>20198</th>
      <td>19</td>
      <td>251579</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>14</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>20606</th>
      <td>25</td>
      <td>308144</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>21048</th>
      <td>21</td>
      <td>250051</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>9</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>21221</th>
      <td>38</td>
      <td>207202</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>6</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>21860</th>
      <td>27</td>
      <td>255582</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>6</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>22086</th>
      <td>20</td>
      <td>107658</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>12</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>22123</th>
      <td>25</td>
      <td>195994</td>
      <td>3</td>
      <td>2</td>
      <td>4</td>
      <td>8</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>12</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>23271</th>
      <td>19</td>
      <td>138153</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>3</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>23334</th>
      <td>49</td>
      <td>43479</td>
      <td>15</td>
      <td>10</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>24201</th>
      <td>49</td>
      <td>31267</td>
      <td>5</td>
      <td>4</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>24361</th>
      <td>21</td>
      <td>243368</td>
      <td>13</td>
      <td>1</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>24960</th>
      <td>28</td>
      <td>274679</td>
      <td>12</td>
      <td>14</td>
      <td>4</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>26648</th>
      <td>42</td>
      <td>204235</td>
      <td>15</td>
      <td>10</td>
      <td>2</td>
      <td>9</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>28246</th>
      <td>46</td>
      <td>133616</td>
      <td>15</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>29365</th>
      <td>25</td>
      <td>195994</td>
      <td>3</td>
      <td>2</td>
      <td>4</td>
      <td>8</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>12</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>31470</th>
      <td>19</td>
      <td>146679</td>
      <td>15</td>
      <td>10</td>
      <td>4</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>30</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>32578</th>
      <td>46</td>
      <td>173243</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>33127</th>
      <td>35</td>
      <td>379959</td>
      <td>11</td>
      <td>9</td>
      <td>0</td>
      <td>7</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>33256</th>
      <td>30</td>
      <td>144593</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>7</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>33954</th>
      <td>19</td>
      <td>97261</td>
      <td>11</td>
      <td>9</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>34197</th>
      <td>44</td>
      <td>367749</td>
      <td>9</td>
      <td>13</td>
      <td>4</td>
      <td>9</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>37384</th>
      <td>23</td>
      <td>240137</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>5</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>55</td>
      <td>25</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>41905</th>
      <td>39</td>
      <td>30916</td>
      <td>11</td>
      <td>9</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>38</td>
      <td>0</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Remove the identified duplicate records 

adult_inc = adult_inc.drop_duplicates()
```


```python
import seaborn as sns
sns.boxplot(adult_inc['hours_per_week'])
```




    <AxesSubplot:xlabel='hours_per_week'>




    
![png](output_37_1.png)
    



```python
#removing outliers from hours-per-week

def remove_outlier_hours_per_week(income):
    IQR=adult_inc['hours_per_week'].quantile(0.75)-adult_inc['hours_per_week'].quantile(0.25)
    lower_range=adult_inc['hours_per_week'].quantile(0.25)-(1.5*IQR)
    upper_range=adult_inc['hours_per_week'].quantile(0.75)+(1.5*IQR)
    
    adult_inc.loc[adult_inc['hours_per_week']<=lower_range,'hours_per_week']=lower_range
    adult_inc.loc[adult_inc['hours_per_week']>=upper_range,'hours_per_week']=upper_range
```


```python
remove_outlier_hours_per_week(adult_inc)
```


```python
sns.boxplot(adult_inc['hours_per_week'])
```




    <AxesSubplot:xlabel='hours_per_week'>




    
![png](output_40_1.png)
    



```python
sns.boxplot(adult_inc['capital_loss'])
```




    <AxesSubplot:xlabel='capital_loss'>




    
![png](output_41_1.png)
    



```python
#removing outliers from capital-loss

def remove_outlier_capital_loss(adult_inc):
    IQR=adult_inc['capital_loss'].quantile(0.75)-adult_inc['capital_loss'].quantile(0.25)
    lower_range=adult_inc['capital_loss'].quantile(0.25)-(1.5*IQR)
    upper_range=adult_inc['capital_loss'].quantile(0.75)+(1.5*IQR)
    
    adult_inc.loc[adult_inc['capital_loss']<=lower_range,'capital_loss']=lower_range
    adult_inc.loc[adult_inc['capital_loss']>=upper_range,'capital_loss']=upper_range
```


```python
remove_outlier_capital_loss(adult_inc)
```


```python
sns.boxplot(adult_inc['capital_loss'])
```




    <AxesSubplot:xlabel='capital_loss'>




    
![png](output_44_1.png)
    



```python
# Identify the independent and Target (dependent) variables

IndepVar = []
for col in adult_inc.columns:
    if col != 'income':
        IndepVar.append(col)

TargetVar = 'income'

x = adult_inc[IndepVar]
y = adult_inc[TargetVar]
```


```python
x=x.drop(['workclass1','education','race','gender','capital_loss','native_country'],axis=1)
```


```python
from imblearn.over_sampling import RandomOverSampler
ros = RandomOverSampler(random_state=42)
```


```python
ros.fit(x, y)
```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomOverSampler(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">RandomOverSampler</label><div class="sk-toggleable__content"><pre>RandomOverSampler(random_state=42)</pre></div></div></div></div></div>




```python
x,y = ros.fit_resample(x, y)
```

# Split Dataset into Training set and Test set


```python
# Splitting the dataset into train and test 

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.20, random_state = 42)

# Display the shape 

x_train.shape, x_test.shape, y_train.shape, y_test.shape
```




    ((59372, 8), (14844, 8), (59372,), (14844,))




```python
# Scaling the features by using MinMaxScaler

from sklearn.preprocessing import StandardScaler

mmscaler = StandardScaler()
for i in x_train.columns:
    x_train[i]= mmscaler.fit_transform(x_train[i].values.reshape(-1,1))
    x_train [i]= pd.DataFrame(x_train[i])
for i in x_test.columns:
    x_test[i] = mmscaler.fit_transform(x_test[i].values.reshape(-1,1))
    x_test[i] = pd.DataFrame(x_test[i])
```


```python
x_train.sample(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>fnlwgt</th>
      <th>educational-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>capital_gain</th>
      <th>hours_per_week</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>40850</th>
      <td>-0.200246</td>
      <td>0.155920</td>
      <td>-1.381076</td>
      <td>-0.322108</td>
      <td>-1.567110</td>
      <td>2.342573</td>
      <td>-0.198444</td>
      <td>-1.548501</td>
    </tr>
    <tr>
      <th>30720</th>
      <td>-1.201319</td>
      <td>-1.236603</td>
      <td>0.918170</td>
      <td>1.166100</td>
      <td>-0.810038</td>
      <td>1.112221</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>63786</th>
      <td>-0.277251</td>
      <td>2.004776</td>
      <td>0.918170</td>
      <td>-0.322108</td>
      <td>-1.567110</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>51755</th>
      <td>-0.277251</td>
      <td>0.770202</td>
      <td>-0.231453</td>
      <td>-0.322108</td>
      <td>-0.810038</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>118</th>
      <td>0.261788</td>
      <td>-0.087433</td>
      <td>-0.614661</td>
      <td>0.421996</td>
      <td>-1.567110</td>
      <td>1.727397</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>67725</th>
      <td>0.107777</td>
      <td>-1.059831</td>
      <td>-0.231453</td>
      <td>-1.810316</td>
      <td>-0.810038</td>
      <td>1.727397</td>
      <td>-0.198444</td>
      <td>1.634584</td>
    </tr>
    <tr>
      <th>55791</th>
      <td>-0.046234</td>
      <td>-0.246507</td>
      <td>-0.231453</td>
      <td>-0.322108</td>
      <td>1.461181</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>1.634584</td>
    </tr>
    <tr>
      <th>27981</th>
      <td>0.261788</td>
      <td>-0.169976</td>
      <td>0.918170</td>
      <td>-0.322108</td>
      <td>0.704108</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>54194</th>
      <td>-0.662280</td>
      <td>0.231020</td>
      <td>-0.231453</td>
      <td>-1.810316</td>
      <td>-1.062395</td>
      <td>1.112221</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>62049</th>
      <td>0.877834</td>
      <td>1.922118</td>
      <td>-0.231453</td>
      <td>-0.322108</td>
      <td>-1.567110</td>
      <td>2.342573</td>
      <td>-0.198444</td>
      <td>-1.150615</td>
    </tr>
    <tr>
      <th>25691</th>
      <td>1.031845</td>
      <td>-1.458647</td>
      <td>0.918170</td>
      <td>-0.322108</td>
      <td>0.704108</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>34540</th>
      <td>-0.200246</td>
      <td>-1.529358</td>
      <td>0.151755</td>
      <td>-0.322108</td>
      <td>-1.062395</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>9378</th>
      <td>-1.278325</td>
      <td>0.462302</td>
      <td>-0.231453</td>
      <td>1.166100</td>
      <td>-1.567110</td>
      <td>-0.118130</td>
      <td>-0.198444</td>
      <td>-1.150615</td>
    </tr>
    <tr>
      <th>55333</th>
      <td>-0.431263</td>
      <td>1.190923</td>
      <td>1.684585</td>
      <td>-0.322108</td>
      <td>0.704108</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>43945</th>
      <td>0.107777</td>
      <td>0.942307</td>
      <td>-0.614661</td>
      <td>-0.322108</td>
      <td>-1.062395</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>1.634584</td>
    </tr>
    <tr>
      <th>39965</th>
      <td>1.339868</td>
      <td>-0.454404</td>
      <td>-2.913906</td>
      <td>-0.322108</td>
      <td>-0.052965</td>
      <td>-0.733306</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>69341</th>
      <td>-0.123240</td>
      <td>-1.448323</td>
      <td>-0.231453</td>
      <td>0.421996</td>
      <td>-1.062395</td>
      <td>1.727397</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
    <tr>
      <th>41832</th>
      <td>-1.509342</td>
      <td>-1.272866</td>
      <td>-0.231453</td>
      <td>1.166100</td>
      <td>1.461181</td>
      <td>1.112221</td>
      <td>-0.198444</td>
      <td>-1.548501</td>
    </tr>
    <tr>
      <th>49980</th>
      <td>2.648964</td>
      <td>-1.033239</td>
      <td>-0.614661</td>
      <td>2.654308</td>
      <td>1.208823</td>
      <td>0.497046</td>
      <td>-0.198444</td>
      <td>-1.150615</td>
    </tr>
    <tr>
      <th>13543</th>
      <td>-0.970302</td>
      <td>-0.922923</td>
      <td>-2.913906</td>
      <td>1.166100</td>
      <td>-0.052965</td>
      <td>1.727397</td>
      <td>-0.198444</td>
      <td>-0.354844</td>
    </tr>
  </tbody>
</table>
</div>




```python
CSResults =pd.read_csv(r"C:\Users\Rashee\Downloads\HTResults1.csv",header=0)
CSResults.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model Name</th>
      <th>True Positive</th>
      <th>False Negative</th>
      <th>False Positive</th>
      <th>True Negative</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
      <th>Specificity</th>
      <th>MCC</th>
      <th>ROC_AUC_Score</th>
      <th>Balanced Accuracy</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



# Comparing All Models


```python
CSResults= pd.DataFrame({'Model Name' :[],
               'True_Positive' : [], 
               'False_Negative' : [], 
               'False_Positive' : [],
               'True_Negative' : [],
               'Accuracy' : [],
               'Precision' : [],
               'Recall' : [],
               'F1 Score' : [],
               'Specificity' : [],
               'MCC':[],
               'ROC_AUC_Score':[],
               'Balanced Accuracy':[]})
```


```python
# Build the Calssification models and compare the results

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.ensemble import BaggingClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import GradientBoostingClassifier
import lightgbm as lgb

# Create objects of classification algorithm with default hyper-parameters

ModelLR = LogisticRegression()
ModelDC = DecisionTreeClassifier()
ModelRF = RandomForestClassifier()
ModelET = ExtraTreesClassifier()
ModelKNN = KNeighborsClassifier(n_neighbors=5)
ModelSVM = SVC(probability=True)
modelBAG = BaggingClassifier(base_estimator=None, n_estimators=100, max_samples=1.0, max_features=1.0,
                             bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False,
                             n_jobs=None, random_state=None, verbose=0)
modelXGB = XGBClassifier(n_estimators=100, max_depth=3, eval_metric='mlogloss')
ModelGB = GradientBoostingClassifier()
ModelLGB = lgb.LGBMClassifier()
ModelGNB = GaussianNB()

# Evalution matrix for all the algorithms

MM = [ModelLR, ModelDC, ModelRF, ModelET, ModelKNN, ModelSVM, modelBAG,modelXGB, ModelGB, ModelLGB, ModelGNB]
for models in MM:
    
    # Fit the model
    
    models.fit(x_train,y_train)
    
    # Prediction
    
    y_pred = models.predict(x_test)
    y_pred_prob = models.predict_proba(x_test)
    
    # Print the model name
    
    print('Model Name: ', models)
    
    # confusion matrix in sklearn

    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import classification_report

    # actual values

    actual = y_test

    # predicted values

    predicted = y_pred

    # confusion matrix

    matrix = confusion_matrix(actual,predicted, labels=[1,0],sample_weight=None, normalize=None)
    print('Confusion matrix : \n', matrix)

    # outcome values order in sklearn

    tp, fn, fp, tn = confusion_matrix(actual,predicted,labels=[1,0]).reshape(-1)
    print('Outcome values : \n', tp, fn, fp, tn)

    # classification report for precision, recall f1-score and accuracy

    C_Report = classification_report(actual,predicted,labels=[1,0])

    print('Classification report : \n', C_Report)

    # calculating the metrics

    sensitivity = round(tp/(tp+fn), 3);
    specificity = round(tn/(tn+fp), 3);
    accuracy = round((tp+tn)/(tp+fp+tn+fn), 3);
    balanced_accuracy = round((sensitivity+specificity)/2, 3);
    
    precision = round(tp/(tp+fp), 3);
    f1Score = round((2*tp/(2*tp + fp + fn)), 3);

    # Matthews Correlation Coefficient (MCC). Range of values of MCC lie between -1 to +1. 
    # A model with a score of +1 is a perfect model and -1 is a poor model

    from math import sqrt

    mx = (tp+fp) * (tp+fn) * (tn+fp) * (tn+fn)
    MCC = round(((tp * tn) - (fp * fn)) / sqrt(mx), 3)

    print('Accuracy :', round(accuracy*100, 2),'%')
    print('Precision :', round(precision*100, 2),'%')
    print('Recall :', round(sensitivity*100,2), '%')
    print('F1 Score :', f1Score)
    print('Specificity or True Negative Rate :', round(specificity*100,2), '%'  )
    print('Balanced Accuracy :', round(balanced_accuracy*100, 2),'%')
    print('MCC :', MCC)

    # Area under ROC curve 

    from sklearn.metrics import roc_curve, roc_auc_score

    print('roc_auc_score:', round(roc_auc_score(actual, predicted), 3))
    
    # ROC Curve
    
    from sklearn.metrics import roc_auc_score
    from sklearn.metrics import roc_curve
    logit_roc_auc = roc_auc_score(actual, predicted)
    fpr, tpr, thresholds = roc_curve(actual, models.predict_proba(x_test)[:,1])
    plt.figure()
    # plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
    plt.plot(fpr, tpr, label= 'Classification Model' % logit_roc_auc)
    plt.plot([0, 1], [0, 1],'r--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.savefig('Log_ROC')
    plt.show()
    print('-----------------------------------------------------------------------------------------------------')
    #----------------------------------------------------------------------------------------------------------
    new_row = ({'Model Name' :models,
               'True_Positive' : tp, 
               'False_Negative' :fn, 
               'False_Positive' :fp,
               'True_Negative' :tn,
               'Accuracy' :accuracy,
               'Precision' :precision,
               'Recall' : sensitivity,
               'F1 Score' :f1Score,
               'Specificity' :specificity,
               'MCC':MCC,
               'ROC_AUC_Score':roc_auc_score(actual, predicted),
               'Balanced Accuracy':balanced_accuracy})
    CSResults = CSResults.append(new_row, ignore_index=True)
    #----------------------------------------------------------------------------------------------------------
```

    Model Name:  LogisticRegression()
    Confusion matrix : 
     [[5602 1807]
     [1810 5625]]
    Outcome values : 
     5602 1807 1810 5625
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.76      0.76      0.76      7409
               0       0.76      0.76      0.76      7435
    
        accuracy                           0.76     14844
       macro avg       0.76      0.76      0.76     14844
    weighted avg       0.76      0.76      0.76     14844
    
    Accuracy : 75.6 %
    Precision : 75.6 %
    Recall : 75.6 %
    F1 Score : 0.756
    Specificity or True Negative Rate : 75.7 %
    Balanced Accuracy : 75.6 %
    MCC : 0.513
    roc_auc_score: 0.756
    


    
![png](output_57_1.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  DecisionTreeClassifier()
    Confusion matrix : 
     [[6768  641]
     [1092 6343]]
    Outcome values : 
     6768 641 1092 6343
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.86      0.91      0.89      7409
               0       0.91      0.85      0.88      7435
    
        accuracy                           0.88     14844
       macro avg       0.88      0.88      0.88     14844
    weighted avg       0.88      0.88      0.88     14844
    
    Accuracy : 88.3 %
    Precision : 86.1 %
    Recall : 91.3 %
    F1 Score : 0.887
    Specificity or True Negative Rate : 85.3 %
    Balanced Accuracy : 88.3 %
    MCC : 0.768
    roc_auc_score: 0.883
    


    
![png](output_57_3.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  RandomForestClassifier()
    Confusion matrix : 
     [[7108  301]
     [ 902 6533]]
    Outcome values : 
     7108 301 902 6533
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.89      0.96      0.92      7409
               0       0.96      0.88      0.92      7435
    
        accuracy                           0.92     14844
       macro avg       0.92      0.92      0.92     14844
    weighted avg       0.92      0.92      0.92     14844
    
    Accuracy : 91.9 %
    Precision : 88.7 %
    Recall : 95.9 %
    F1 Score : 0.922
    Specificity or True Negative Rate : 87.9 %
    Balanced Accuracy : 91.9 %
    MCC : 0.841
    roc_auc_score: 0.919
    


    
![png](output_57_5.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  ExtraTreesClassifier()
    Confusion matrix : 
     [[7161  248]
     [ 772 6663]]
    Outcome values : 
     7161 248 772 6663
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.90      0.97      0.93      7409
               0       0.96      0.90      0.93      7435
    
        accuracy                           0.93     14844
       macro avg       0.93      0.93      0.93     14844
    weighted avg       0.93      0.93      0.93     14844
    
    Accuracy : 93.1 %
    Precision : 90.3 %
    Recall : 96.7 %
    F1 Score : 0.934
    Specificity or True Negative Rate : 89.6 %
    Balanced Accuracy : 93.2 %
    MCC : 0.865
    roc_auc_score: 0.931
    


    
![png](output_57_7.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  KNeighborsClassifier()
    Confusion matrix : 
     [[6613  796]
     [1691 5744]]
    Outcome values : 
     6613 796 1691 5744
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.80      0.89      0.84      7409
               0       0.88      0.77      0.82      7435
    
        accuracy                           0.83     14844
       macro avg       0.84      0.83      0.83     14844
    weighted avg       0.84      0.83      0.83     14844
    
    Accuracy : 83.2 %
    Precision : 79.6 %
    Recall : 89.3 %
    F1 Score : 0.842
    Specificity or True Negative Rate : 77.3 %
    Balanced Accuracy : 83.3 %
    MCC : 0.67
    roc_auc_score: 0.833
    


    
![png](output_57_9.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  SVC(probability=True)
    Confusion matrix : 
     [[6538  871]
     [1786 5649]]
    Outcome values : 
     6538 871 1786 5649
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.79      0.88      0.83      7409
               0       0.87      0.76      0.81      7435
    
        accuracy                           0.82     14844
       macro avg       0.83      0.82      0.82     14844
    weighted avg       0.83      0.82      0.82     14844
    
    Accuracy : 82.1 %
    Precision : 78.5 %
    Recall : 88.2 %
    F1 Score : 0.831
    Specificity or True Negative Rate : 76.0 %
    Balanced Accuracy : 82.1 %
    MCC : 0.647
    roc_auc_score: 0.821
    


    
![png](output_57_11.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  BaggingClassifier(n_estimators=100)
    Confusion matrix : 
     [[7076  333]
     [ 964 6471]]
    Outcome values : 
     7076 333 964 6471
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.88      0.96      0.92      7409
               0       0.95      0.87      0.91      7435
    
        accuracy                           0.91     14844
       macro avg       0.92      0.91      0.91     14844
    weighted avg       0.92      0.91      0.91     14844
    
    Accuracy : 91.3 %
    Precision : 88.0 %
    Recall : 95.5 %
    F1 Score : 0.916
    Specificity or True Negative Rate : 87.0 %
    Balanced Accuracy : 91.2 %
    MCC : 0.828
    roc_auc_score: 0.913
    


    
![png](output_57_13.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  XGBClassifier(base_score=0.5, booster='gbtree', callbacks=None,
                  colsample_bylevel=1, colsample_bynode=1, colsample_bytree=1,
                  early_stopping_rounds=None, enable_categorical=False,
                  eval_metric='mlogloss', gamma=0, gpu_id=-1,
                  grow_policy='depthwise', importance_type=None,
                  interaction_constraints='', learning_rate=0.300000012,
                  max_bin=256, max_cat_to_onehot=4, max_delta_step=0, max_depth=3,
                  max_leaves=0, min_child_weight=1, missing=nan,
                  monotone_constraints='()', n_estimators=100, n_jobs=0,
                  num_parallel_tree=1, predictor='auto', random_state=0,
                  reg_alpha=0, reg_lambda=1, ...)
    Confusion matrix : 
     [[6247 1162]
     [1456 5979]]
    Outcome values : 
     6247 1162 1456 5979
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.81      0.84      0.83      7409
               0       0.84      0.80      0.82      7435
    
        accuracy                           0.82     14844
       macro avg       0.82      0.82      0.82     14844
    weighted avg       0.82      0.82      0.82     14844
    
    Accuracy : 82.4 %
    Precision : 81.1 %
    Recall : 84.3 %
    F1 Score : 0.827
    Specificity or True Negative Rate : 80.4 %
    Balanced Accuracy : 82.4 %
    MCC : 0.648
    roc_auc_score: 0.824
    


    
![png](output_57_15.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  GradientBoostingClassifier()
    Confusion matrix : 
     [[6352 1057]
     [1466 5969]]
    Outcome values : 
     6352 1057 1466 5969
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.81      0.86      0.83      7409
               0       0.85      0.80      0.83      7435
    
        accuracy                           0.83     14844
       macro avg       0.83      0.83      0.83     14844
    weighted avg       0.83      0.83      0.83     14844
    
    Accuracy : 83.0 %
    Precision : 81.2 %
    Recall : 85.7 %
    F1 Score : 0.834
    Specificity or True Negative Rate : 80.3 %
    Balanced Accuracy : 83.0 %
    MCC : 0.661
    roc_auc_score: 0.83
    


    
![png](output_57_17.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  LGBMClassifier()
    Confusion matrix : 
     [[6407 1002]
     [1432 6003]]
    Outcome values : 
     6407 1002 1432 6003
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.82      0.86      0.84      7409
               0       0.86      0.81      0.83      7435
    
        accuracy                           0.84     14844
       macro avg       0.84      0.84      0.84     14844
    weighted avg       0.84      0.84      0.84     14844
    
    Accuracy : 83.6 %
    Precision : 81.7 %
    Recall : 86.5 %
    F1 Score : 0.84
    Specificity or True Negative Rate : 80.7 %
    Balanced Accuracy : 83.6 %
    MCC : 0.673
    roc_auc_score: 0.836
    


    
![png](output_57_19.png)
    


    -----------------------------------------------------------------------------------------------------
    Model Name:  GaussianNB()
    Confusion matrix : 
     [[2788 4621]
     [ 315 7120]]
    Outcome values : 
     2788 4621 315 7120
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.90      0.38      0.53      7409
               0       0.61      0.96      0.74      7435
    
        accuracy                           0.67     14844
       macro avg       0.75      0.67      0.64     14844
    weighted avg       0.75      0.67      0.64     14844
    
    Accuracy : 66.7 %
    Precision : 89.8 %
    Recall : 37.6 %
    F1 Score : 0.53
    Specificity or True Negative Rate : 95.8 %
    Balanced Accuracy : 66.7 %
    MCC : 0.411
    roc_auc_score: 0.667
    


    
![png](output_57_21.png)
    


    -----------------------------------------------------------------------------------------------------
    


```python
CSResults
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model Name</th>
      <th>True_Positive</th>
      <th>False_Negative</th>
      <th>False_Positive</th>
      <th>True_Negative</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
      <th>Specificity</th>
      <th>MCC</th>
      <th>ROC_AUC_Score</th>
      <th>Balanced Accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LogisticRegression()</td>
      <td>5602.0</td>
      <td>1807.0</td>
      <td>1810.0</td>
      <td>5625.0</td>
      <td>0.756</td>
      <td>0.756</td>
      <td>0.756</td>
      <td>0.756</td>
      <td>0.757</td>
      <td>0.513</td>
      <td>0.756332</td>
      <td>0.756</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DecisionTreeClassifier()</td>
      <td>6768.0</td>
      <td>641.0</td>
      <td>1092.0</td>
      <td>6343.0</td>
      <td>0.883</td>
      <td>0.861</td>
      <td>0.913</td>
      <td>0.887</td>
      <td>0.853</td>
      <td>0.768</td>
      <td>0.883305</td>
      <td>0.883</td>
    </tr>
    <tr>
      <th>2</th>
      <td>(DecisionTreeClassifier(max_features='sqrt', r...</td>
      <td>7108.0</td>
      <td>301.0</td>
      <td>902.0</td>
      <td>6533.0</td>
      <td>0.919</td>
      <td>0.887</td>
      <td>0.959</td>
      <td>0.922</td>
      <td>0.879</td>
      <td>0.841</td>
      <td>0.919028</td>
      <td>0.919</td>
    </tr>
    <tr>
      <th>3</th>
      <td>(ExtraTreeClassifier(random_state=320019314), ...</td>
      <td>7161.0</td>
      <td>248.0</td>
      <td>772.0</td>
      <td>6663.0</td>
      <td>0.931</td>
      <td>0.903</td>
      <td>0.967</td>
      <td>0.934</td>
      <td>0.896</td>
      <td>0.865</td>
      <td>0.931347</td>
      <td>0.932</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KNeighborsClassifier()</td>
      <td>6613.0</td>
      <td>796.0</td>
      <td>1691.0</td>
      <td>5744.0</td>
      <td>0.832</td>
      <td>0.796</td>
      <td>0.893</td>
      <td>0.842</td>
      <td>0.773</td>
      <td>0.670</td>
      <td>0.832563</td>
      <td>0.833</td>
    </tr>
    <tr>
      <th>5</th>
      <td>SVC(probability=True)</td>
      <td>6538.0</td>
      <td>871.0</td>
      <td>1786.0</td>
      <td>5649.0</td>
      <td>0.821</td>
      <td>0.785</td>
      <td>0.882</td>
      <td>0.831</td>
      <td>0.760</td>
      <td>0.647</td>
      <td>0.821113</td>
      <td>0.821</td>
    </tr>
    <tr>
      <th>6</th>
      <td>(DecisionTreeClassifier(random_state=205441900...</td>
      <td>7076.0</td>
      <td>333.0</td>
      <td>964.0</td>
      <td>6471.0</td>
      <td>0.913</td>
      <td>0.880</td>
      <td>0.955</td>
      <td>0.916</td>
      <td>0.870</td>
      <td>0.828</td>
      <td>0.912699</td>
      <td>0.912</td>
    </tr>
    <tr>
      <th>7</th>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>6247.0</td>
      <td>1162.0</td>
      <td>1456.0</td>
      <td>5979.0</td>
      <td>0.824</td>
      <td>0.811</td>
      <td>0.843</td>
      <td>0.827</td>
      <td>0.804</td>
      <td>0.648</td>
      <td>0.823667</td>
      <td>0.824</td>
    </tr>
    <tr>
      <th>8</th>
      <td>([DecisionTreeRegressor(criterion='friedman_ms...</td>
      <td>6352.0</td>
      <td>1057.0</td>
      <td>1466.0</td>
      <td>5969.0</td>
      <td>0.830</td>
      <td>0.812</td>
      <td>0.857</td>
      <td>0.834</td>
      <td>0.803</td>
      <td>0.661</td>
      <td>0.830080</td>
      <td>0.830</td>
    </tr>
    <tr>
      <th>9</th>
      <td>LGBMClassifier()</td>
      <td>6407.0</td>
      <td>1002.0</td>
      <td>1432.0</td>
      <td>6003.0</td>
      <td>0.836</td>
      <td>0.817</td>
      <td>0.865</td>
      <td>0.840</td>
      <td>0.807</td>
      <td>0.673</td>
      <td>0.836078</td>
      <td>0.836</td>
    </tr>
    <tr>
      <th>10</th>
      <td>GaussianNB()</td>
      <td>2788.0</td>
      <td>4621.0</td>
      <td>315.0</td>
      <td>7120.0</td>
      <td>0.667</td>
      <td>0.898</td>
      <td>0.376</td>
      <td>0.530</td>
      <td>0.958</td>
      <td>0.411</td>
      <td>0.666966</td>
      <td>0.667</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Load the Hyperparameter tunining result dataset

HTResults = pd.read_csv(r"C:\Users\Rashee\OneDrive - SRKR Engineering College\drive\OneDrive - SRKR Engineering College\Desktop\AI\CSResults1.csv", header=0)
HTResults.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model Name</th>
      <th>True Positive</th>
      <th>False Negative</th>
      <th>False Positive</th>
      <th>True Negative</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
      <th>Specificity</th>
      <th>MCC</th>
      <th>ROC_AUC_Score</th>
      <th>Balanced Accuracy</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# Hyperparameter tuning using RandomizedSearchCV

n_estimators = [int(x) for x in np.linspace(start = 200, stop = 2000, num = 10)] # number of trees in the random forest 
max_features = ['auto', 'sqrt', 'log2'] # number of features in consideration at every split
max_depth = [int(x) for x in np.linspace(10, 120, num = 12)] # maximum number of levels allowed in each decision tree
min_samples_split = [2, 6, 10] # minimum sample number to split a node
min_samples_leaf = [1, 3, 4] # minimum sample number that can be stored in a leaf node
bootstrap = [True, False] # method used to sample data points

random_grid = {'n_estimators': n_estimators,

'max_features': max_features,

'max_depth': max_depth,

'min_samples_split': min_samples_split,

'min_samples_leaf': min_samples_leaf,

'bootstrap': bootstrap}
```


```python
# Importing Random Forest Classifier from the sklearn.ensemble

from sklearn.ensemble import RandomForestClassifier

ModelRF4 = RandomForestClassifier()

from sklearn.model_selection import RandomizedSearchCV

rf_random = RandomizedSearchCV(estimator = ModelRF4,param_distributions = random_grid,
                               n_iter = 100, cv = 3, verbose=2, random_state=35, n_jobs = -1)

# Fit the model with train data

rf_random.fit(x_train, y_train)
```

    Fitting 3 folds for each of 100 candidates, totalling 300 fits
    




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomizedSearchCV(cv=3, estimator=RandomForestClassifier(), n_iter=100,
                   n_jobs=-1,
                   param_distributions={&#x27;bootstrap&#x27;: [True, False],
                                        &#x27;max_depth&#x27;: [10, 20, 30, 40, 50, 60,
                                                      70, 80, 90, 100, 110,
                                                      120],
                                        &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;min_samples_leaf&#x27;: [1, 3, 4],
                                        &#x27;min_samples_split&#x27;: [2, 6, 10],
                                        &#x27;n_estimators&#x27;: [200, 400, 600, 800,
                                                         1000, 1200, 1400, 1600,
                                                         1800, 2000]},
                   random_state=35, verbose=2)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">RandomizedSearchCV</label><div class="sk-toggleable__content"><pre>RandomizedSearchCV(cv=3, estimator=RandomForestClassifier(), n_iter=100,
                   n_jobs=-1,
                   param_distributions={&#x27;bootstrap&#x27;: [True, False],
                                        &#x27;max_depth&#x27;: [10, 20, 30, 40, 50, 60,
                                                      70, 80, 90, 100, 110,
                                                      120],
                                        &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;min_samples_leaf&#x27;: [1, 3, 4],
                                        &#x27;min_samples_split&#x27;: [2, 6, 10],
                                        &#x27;n_estimators&#x27;: [200, 400, 600, 800,
                                                         1000, 1200, 1400, 1600,
                                                         1800, 2000]},
                   random_state=35, verbose=2)</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" ><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
best_grid = rf_random.best_estimator_
best_grid
```




<style>#sk-container-id-3 {color: black;background-color: white;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(bootstrap=False, max_depth=70, max_features=&#x27;auto&#x27;,
                       n_estimators=1000)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" checked><label for="sk-estimator-id-5" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier(bootstrap=False, max_depth=70, max_features=&#x27;auto&#x27;,
                       n_estimators=1000)</pre></div></div></div></div></div>




```python
# To build the 'RandomForestClassifier' model with random sampling with Hyperparametr tuning with RandomizedSearchCV

from sklearn.ensemble import RandomForestClassifier

ModelRF5 = RandomForestClassifier(n_estimators=1000, criterion='gini', max_depth=70, min_samples_split=6,
                                  min_samples_leaf=4, min_weight_fraction_leaf=0.0, max_features='auto', 
                                  max_leaf_nodes=None, min_impurity_decrease=0.0, bootstrap=False, oob_score=False, 
                                  n_jobs=None, random_state=None, verbose=0, warm_start=False, class_weight=None, 
                                  ccp_alpha=0.0, max_samples=None)

# Train the model with train data 

ModelRF5.fit(x_train,y_train)

# Predict the model with test data set

y_pred = ModelRF5.predict(x_test)
y_pred_prob = ModelRF5.predict_proba(x_test)

# Confusion matrix in sklearn

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

# actual values

actual = y_test

# predicted values

predicted = y_pred

# confusion matrix

matrix = confusion_matrix(actual,predicted, labels=[1,0],sample_weight=None, normalize=None)
print('Confusion matrix : \n', matrix)

# outcome values order in sklearn

tp, fn, fp, tn = confusion_matrix(actual,predicted,labels=[1,0]).reshape(-1)
print('Outcome values : \n', tp, fn, fp, tn)

# classification report for precision, recall f1-score and accuracy

C_Report = classification_report(actual,predicted,labels=[1,0])

print('Classification report : \n', C_Report)

# calculating the metrics

sensitivity = round(tp/(tp+fn), 3);
specificity = round(tn/(tn+fp), 3);
accuracy = round((tp+tn)/(tp+fp+tn+fn), 3);
balanced_accuracy = round((sensitivity+specificity)/2, 3);
precision = round(tp/(tp+fp), 3);
f1Score = round((2*tp/(2*tp + fp + fn)), 3);

# Matthews Correlation Coefficient (MCC). Range of values of MCC lie between -1 to +1. 
# A model with a score of +1 is a perfect model and -1 is a poor model

from math import sqrt

mx = (tp+fp) * (tp+fn) * (tn+fp) * (tn+fn)
MCC = round(((tp * tn) - (fp * fn)) / sqrt(mx), 3)

print('Accuracy :', round(accuracy*100, 2),'%')
print('Precision :', round(precision*100, 2),'%')
print('Recall :', round(sensitivity*100,2), '%')
print('F1 Score :', f1Score)
print('Specificity or True Negative Rate :', round(specificity*100,2), '%'  )
print('Balanced Accuracy :', round(balanced_accuracy*100, 2),'%')
print('MCC :', MCC)

# Area under ROC curve 

from sklearn.metrics import roc_curve, roc_auc_score

print('roc_auc_score:', round(roc_auc_score(actual, predicted), 3))

# ROC Curve

from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
logit_roc_auc = roc_auc_score(actual, predicted)
fpr, tpr, thresholds = roc_curve(actual, ModelRF5.predict_proba(x_test)[:,1])
plt.figure()
# plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot(fpr, tpr, label= 'Classification Model' % logit_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.savefig('Log_ROC')
plt.show() 
print('-----------------------------------------------------------------------------------------------------')
#----------------------------------------------------------------------------------------------------------
new_row = {'Model Name' : ModelRF5,
           'True_Positive': tp,
           'False_Negative': fn, 
           'False_Positive': fp, 
           'True_Negative': tn,
           'Accuracy' : accuracy,
           'Precision' : precision,
           'Recall' : sensitivity,
           'F1 Score' : f1Score,
           'Specificity' : specificity,
           'MCC':MCC,
           'ROC_AUC_Score':roc_auc_score(actual, predicted),
           'Balanced Accuracy':balanced_accuracy}
HTResults = HTResults.append(new_row, ignore_index=True)
#----------------------------------------------------------------------------------------------------------
```

    Confusion matrix : 
     [[6925  539]
     [1095 6285]]
    Outcome values : 
     6925 539 1095 6285
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.86      0.93      0.89      7464
               0       0.92      0.85      0.88      7380
    
        accuracy                           0.89     14844
       macro avg       0.89      0.89      0.89     14844
    weighted avg       0.89      0.89      0.89     14844
    
    Accuracy : 89.0 %
    Precision : 86.3 %
    Recall : 92.8 %
    F1 Score : 0.894
    Specificity or True Negative Rate : 85.2 %
    Balanced Accuracy : 89.0 %
    MCC : 0.782
    roc_auc_score: 0.89
    


    
![png](output_63_1.png)
    


    -----------------------------------------------------------------------------------------------------
    


```python
# Hyperparameter tuning by GridSearchCV

from sklearn.model_selection import GridSearchCV

# Create the parameter grid based on the results of random search 
GS_grid = {
    'bootstrap': [True, False],
    'max_depth': [10,15],
    'max_features': ['auto', 'sqrt', 'log2'],
    'min_samples_leaf': [3, 4, 5, 6],
    'min_samples_split': [3,4,5,6],
    'n_estimators': [100, 200, 300, 400, 500]
}

# Create object for model

ModelRF2 = RandomForestClassifier()

# Instantiate the grid search model

Grid_search = GridSearchCV(estimator = ModelRF2, param_grid = GS_grid, cv = 3, n_jobs = -1, verbose = 2)

# Fit the grid search to the data

Grid_search.fit(x_train,y_train)
```

    Fitting 3 folds for each of 960 candidates, totalling 2880 fits
    




<style>#sk-container-id-4 {color: black;background-color: white;}#sk-container-id-4 pre{padding: 0;}#sk-container-id-4 div.sk-toggleable {background-color: white;}#sk-container-id-4 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-4 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-4 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-4 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-4 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-4 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-4 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-4 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-4 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-4 div.sk-item {position: relative;z-index: 1;}#sk-container-id-4 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-4 div.sk-item::before, #sk-container-id-4 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-4 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-4 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-4 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-4 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-4 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-4 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-4 div.sk-label-container {text-align: center;}#sk-container-id-4 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-4 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=3, estimator=RandomForestClassifier(), n_jobs=-1,
             param_grid={&#x27;bootstrap&#x27;: [True, False], &#x27;max_depth&#x27;: [10, 15],
                         &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;, &#x27;log2&#x27;],
                         &#x27;min_samples_leaf&#x27;: [3, 4, 5, 6],
                         &#x27;min_samples_split&#x27;: [3, 4, 5, 6],
                         &#x27;n_estimators&#x27;: [100, 200, 300, 400, 500]},
             verbose=2)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" ><label for="sk-estimator-id-6" class="sk-toggleable__label sk-toggleable__label-arrow">GridSearchCV</label><div class="sk-toggleable__content"><pre>GridSearchCV(cv=3, estimator=RandomForestClassifier(), n_jobs=-1,
             param_grid={&#x27;bootstrap&#x27;: [True, False], &#x27;max_depth&#x27;: [10, 15],
                         &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;, &#x27;log2&#x27;],
                         &#x27;min_samples_leaf&#x27;: [3, 4, 5, 6],
                         &#x27;min_samples_split&#x27;: [3, 4, 5, 6],
                         &#x27;n_estimators&#x27;: [100, 200, 300, 400, 500]},
             verbose=2)</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-8" type="checkbox" ><label for="sk-estimator-id-8" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python

# Best parameter from gridseachCV
Grid_search.best_params_
```




    {'bootstrap': False,
     'max_depth': 15,
     'max_features': 'log2',
     'min_samples_leaf': 3,
     'min_samples_split': 4,
     'n_estimators': 500}




```python
# Display of best parameter

best_grid = Grid_search.best_estimator_
best_grid
```




<style>#sk-container-id-5 {color: black;background-color: white;}#sk-container-id-5 pre{padding: 0;}#sk-container-id-5 div.sk-toggleable {background-color: white;}#sk-container-id-5 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-5 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-5 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-5 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-5 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-5 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-5 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-5 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-5 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-5 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-5 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-5 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-5 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-5 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-5 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-5 div.sk-item {position: relative;z-index: 1;}#sk-container-id-5 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-5 div.sk-item::before, #sk-container-id-5 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-5 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-5 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-5 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-5 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-5 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-5 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-5 div.sk-label-container {text-align: center;}#sk-container-id-5 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-5 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-5" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(bootstrap=False, max_depth=15, max_features=&#x27;log2&#x27;,
                       min_samples_leaf=3, min_samples_split=4,
                       n_estimators=500)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-9" type="checkbox" checked><label for="sk-estimator-id-9" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier(bootstrap=False, max_depth=15, max_features=&#x27;log2&#x27;,
                       min_samples_leaf=3, min_samples_split=4,
                       n_estimators=500)</pre></div></div></div></div></div>




```python
# To build the 'ExtraTreesClassifier' model with random sampling with Hyperparameter tuning with GridSearchCV

from sklearn.ensemble import ExtraTreesClassifier

ModelET = ExtraTreesClassifier(bootstrap=False, max_depth=15, max_features='log2',
                       min_samples_leaf=3, min_samples_split=4,
                       n_estimators=500)

# Train the model with train data

ModelET.fit(x_train,y_train)

# Predict the model with test data set

y_pred = ModelET.predict(x_test)
y_pred_prob = ModelET.predict_proba(x_test)

# Confusion matrix in sklearn

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

# actual values

actual = y_test

# predicted values

predicted = y_pred

# confusion matrix

matrix = confusion_matrix(actual,predicted, labels=[1,0],sample_weight=None, normalize=None)
print('Confusion matrix : \n', matrix)

# outcome values order in sklearn

tp, fn, fp, tn = confusion_matrix(actual,predicted,labels=[1,0]).reshape(-1)
print('Outcome values : \n', tp, fn, fp, tn)

# classification report for precision, recall f1-score and accuracy

C_Report = classification_report(actual,predicted,labels=[1,0])

print('Classification report : \n', C_Report)

# calculating the metrics

sensitivity = round(tp/(tp+fn), 3);
specificity = round(tn/(tn+fp), 3);
accuracy = round((tp+tn)/(tp+fp+tn+fn), 3);
balanced_accuracy = round((sensitivity+specificity)/2, 3);
precision = round(tp/(tp+fp), 3);
f1Score = round((2*tp/(2*tp + fp + fn)), 3);

# Matthews Correlation Coefficient (MCC). Range of values of MCC lie between -1 to +1. 
# A model with a score of +1 is a perfect model and -1 is a poor model

from math import sqrt

mx = (tp+fp) * (tp+fn) * (tn+fp) * (tn+fn)
MCC = round(((tp * tn) - (fp * fn)) / sqrt(mx), 3)

print('Accuracy :', round(accuracy*100, 2),'%')
print('Precision :', round(precision*100, 2),'%')
print('Recall :', round(sensitivity*100,2), '%')
print('F1 Score :', f1Score)
print('Specificity or True Negative Rate :', round(specificity*100,2), '%'  )
print('Balanced Accuracy :', round(balanced_accuracy*100, 2),'%')
print('MCC :', MCC)

# Area under ROC curve 

from sklearn.metrics import roc_curve, roc_auc_score

print('roc_auc_score:', round(roc_auc_score(y_test, y_pred), 3))

# ROC Curve

from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
logit_roc_auc = roc_auc_score(y_test, y_pred)
fpr, tpr, thresholds = roc_curve(y_test,ModelET.predict_proba(x_test)[:,1])
plt.figure()
# plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot(fpr, tpr, label= 'Classification Model' % logit_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.savefig('Log_ROC')
plt.show() 
print('-----------------------------------------------------------------------------------------------------')
#----------------------------------------------------------------------------------------------------------
new_row = {'Model Name' : ModelET,
           'True_Positive': tp,
           'False_Negative': fn, 
           'False_Positive': fp, 
           'True_Negative': tn,
           'Accuracy' : accuracy,
           'Precision' : precision,
           'Recall' : sensitivity,
           'F1 Score' : f1Score,
           'Specificity' : specificity,
           'MCC':MCC,
           'ROC_AUC_Score':roc_auc_score(y_test, y_pred),
           'Balanced Accuracy':balanced_accuracy}
HTResults = HTResults.append(new_row, ignore_index=True)
#----------------------------------------------------------------------------------------------------------
```

    Confusion matrix : 
     [[6740  724]
     [1598 5782]]
    Outcome values : 
     6740 724 1598 5782
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.81      0.90      0.85      7464
               0       0.89      0.78      0.83      7380
    
        accuracy                           0.84     14844
       macro avg       0.85      0.84      0.84     14844
    weighted avg       0.85      0.84      0.84     14844
    
    Accuracy : 84.4 %
    Precision : 80.8 %
    Recall : 90.3 %
    F1 Score : 0.853
    Specificity or True Negative Rate : 78.3 %
    Balanced Accuracy : 84.3 %
    MCC : 0.692
    roc_auc_score: 0.843
    


    
![png](output_67_1.png)
    


    -----------------------------------------------------------------------------------------------------
    


```python
HTResults
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model Name</th>
      <th>KNN K Value</th>
      <th>True_Positive</th>
      <th>False_Negative</th>
      <th>False_Positive</th>
      <th>True_Negative</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1 Score</th>
      <th>Specificity</th>
      <th>MCC</th>
      <th>ROC_AUC_Score</th>
      <th>Balanced Accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(ExtraTreeClassifier(max_depth=15, max_feature...</td>
      <td>NaN</td>
      <td>6740</td>
      <td>724</td>
      <td>1598</td>
      <td>5782</td>
      <td>0.844</td>
      <td>0.808</td>
      <td>0.903</td>
      <td>0.853</td>
      <td>0.783</td>
      <td>0.692</td>
      <td>0.843235</td>
      <td>0.843</td>
    </tr>
    <tr>
      <th>1</th>
      <td>(DecisionTreeClassifier(max_depth=70, max_feat...</td>
      <td>NaN</td>
      <td>6925</td>
      <td>539</td>
      <td>1095</td>
      <td>6285</td>
      <td>0.89</td>
      <td>0.863</td>
      <td>0.928</td>
      <td>0.894</td>
      <td>0.852</td>
      <td>0.782</td>
      <td>0.889706</td>
      <td>0.89</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Hyperparameter tuning using RandomizedSearchCV

n_estimators = [int(x) for x in np.linspace(start = 200, stop = 2000, num = 10)] # number of trees in the random forest 
max_features = ['auto', 'sqrt', 'log2'] # number of features in consideration at every split
max_depth = [int(x) for x in np.linspace(10, 120, num = 12)] # maximum number of levels allowed in each decision tree
min_samples_split = [2, 6, 10] # minimum sample number to split a node
min_samples_leaf = [1, 3, 4] # minimum sample number that can be stored in a leaf node
bootstrap = [True, False] # method used to sample data points

random_grid = {'n_estimators': n_estimators,

'max_features': max_features,

'max_depth': max_depth,

'min_samples_split': min_samples_split,

'min_samples_leaf': min_samples_leaf,

'bootstrap': bootstrap}
```


```python
# Importing Random Forest Classifier from the sklearn.ensemble

from sklearn.ensemble import RandomForestClassifier

ModelRF4 = RandomForestClassifier()

from sklearn.model_selection import RandomizedSearchCV

rf_random = RandomizedSearchCV(estimator = ModelRF4,param_distributions = random_grid,
                               n_iter = 100, cv = 3, verbose=2, random_state=35, n_jobs = -1)

# Fit the model with train data

rf_random.fit(x_train, y_train)
```

    Fitting 3 folds for each of 100 candidates, totalling 300 fits
    




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomizedSearchCV(cv=3, estimator=RandomForestClassifier(), n_iter=100,
                   n_jobs=-1,
                   param_distributions={&#x27;bootstrap&#x27;: [True, False],
                                        &#x27;max_depth&#x27;: [10, 20, 30, 40, 50, 60,
                                                      70, 80, 90, 100, 110,
                                                      120],
                                        &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;min_samples_leaf&#x27;: [1, 3, 4],
                                        &#x27;min_samples_split&#x27;: [2, 6, 10],
                                        &#x27;n_estimators&#x27;: [200, 400, 600, 800,
                                                         1000, 1200, 1400, 1600,
                                                         1800, 2000]},
                   random_state=35, verbose=2)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">RandomizedSearchCV</label><div class="sk-toggleable__content"><pre>RandomizedSearchCV(cv=3, estimator=RandomForestClassifier(), n_iter=100,
                   n_jobs=-1,
                   param_distributions={&#x27;bootstrap&#x27;: [True, False],
                                        &#x27;max_depth&#x27;: [10, 20, 30, 40, 50, 60,
                                                      70, 80, 90, 100, 110,
                                                      120],
                                        &#x27;max_features&#x27;: [&#x27;auto&#x27;, &#x27;sqrt&#x27;,
                                                         &#x27;log2&#x27;],
                                        &#x27;min_samples_leaf&#x27;: [1, 3, 4],
                                        &#x27;min_samples_split&#x27;: [2, 6, 10],
                                        &#x27;n_estimators&#x27;: [200, 400, 600, 800,
                                                         1000, 1200, 1400, 1600,
                                                         1800, 2000]},
                   random_state=35, verbose=2)</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" ><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
# Print the best parameters

print ('Random grid: ', random_grid, '\n')

# print the best parameters

print ('Best Parameters: ', rf_random.best_params_, ' \n')
```

    Random grid:  {'n_estimators': [200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000], 'max_features': ['auto', 'sqrt', 'log2'], 'max_depth': [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120], 'min_samples_split': [2, 6, 10], 'min_samples_leaf': [1, 3, 4], 'bootstrap': [True, False]} 
    
    Best Parameters:  {'n_estimators': 1600, 'min_samples_split': 2, 'min_samples_leaf': 1, 'max_features': 'sqrt', 'max_depth': 60, 'bootstrap': False}  
    
    


```python
# To build the 'RandomForestClassifier' model with random sampling with Hyperparametr tuning with RandomizedSearchCV

from sklearn.ensemble import RandomForestClassifier

ModelRF5 = RandomForestClassifier(n_estimators= 1600, min_samples_split= 2,
                                  min_samples_leaf=1, max_features='sqrt',
                                  max_depth=60, bootstrap= False)

# Train the model with train data 

ModelRF5.fit(x_train,y_train)

# Predict the model with test data set

y_pred = ModelRF5.predict(x_test)
y_pred_prob = ModelRF5.predict_proba(x_test)

# Confusion matrix in sklearn

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

# actual values

actual = y_test

# predicted values

predicted = y_pred

# confusion matrix

matrix = confusion_matrix(actual,predicted, labels=[1,0],sample_weight=None, normalize=None)
print('Confusion matrix : \n', matrix)

# outcome values order in sklearn

tp, fn, fp, tn = confusion_matrix(actual,predicted,labels=[1,0]).reshape(-1)
print('Outcome values : \n', tp, fn, fp, tn)

# classification report for precision, recall f1-score and accuracy

C_Report = classification_report(actual,predicted,labels=[1,0])

print('Classification report : \n', C_Report)

# calculating the metrics

sensitivity = round(tp/(tp+fn), 3);
specificity = round(tn/(tn+fp), 3);
accuracy = round((tp+tn)/(tp+fp+tn+fn), 3);
balanced_accuracy = round((sensitivity+specificity)/2, 3);
precision = round(tp/(tp+fp), 3);
f1Score = round((2*tp/(2*tp + fp + fn)), 3);

# Matthews Correlation Coefficient (MCC). Range of values of MCC lie between -1 to +1. 
# A model with a score of +1 is a perfect model and -1 is a poor model

from math import sqrt

mx = (tp+fp) * (tp+fn) * (tn+fp) * (tn+fn)
MCC = round(((tp * tn) - (fp * fn)) / sqrt(mx), 3)

print('Accuracy :', round(accuracy*100, 2),'%')
print('Precision :', round(precision*100, 2),'%')
print('Recall :', round(sensitivity*100,2), '%')
print('F1 Score :', f1Score)
print('Specificity or True Negative Rate :', round(specificity*100,2), '%'  )
print('Balanced Accuracy :', round(balanced_accuracy*100, 2),'%')
print('MCC :', MCC)

# Area under ROC curve 

from sklearn.metrics import roc_curve, roc_auc_score

print('roc_auc_score:', round(roc_auc_score(actual, predicted), 3))

# ROC Curve

from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
logit_roc_auc = roc_auc_score(actual, predicted)
fpr, tpr, thresholds = roc_curve(actual, ModelRF5.predict_proba(x_test)[:,1])
plt.figure()
# plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
plt.plot(fpr, tpr, label= 'Classification Model' % logit_roc_auc)
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.savefig('Log_ROC')
plt.show() 
print('-----------------------------------------------------------------------------------------------------')
#----------------------------------------------------------------------------------------------------------
new_row = {'Model Name' : ModelRF5,
           'True_Positive': tp,
           'False_Negative': fn, 
           'False_Positive': fp, 
           'True_Negative': tn,
           'Accuracy' : accuracy,
           'Precision' : precision,
           'Recall' : sensitivity,
           'F1 Score' : f1Score,
           'Specificity' : specificity,
           'MCC':MCC,
           'ROC_AUC_Score':roc_auc_score(actual, predicted),
           'Balanced Accuracy':balanced_accuracy}
HTResults = HTResults.append(new_row, ignore_index=True)
#----------------------------------------------------------------------------------------------------------
```

    Confusion matrix : 
     [[7074  335]
     [ 736 6699]]
    Outcome values : 
     7074 335 736 6699
    Classification report : 
                   precision    recall  f1-score   support
    
               1       0.91      0.95      0.93      7409
               0       0.95      0.90      0.93      7435
    
        accuracy                           0.93     14844
       macro avg       0.93      0.93      0.93     14844
    weighted avg       0.93      0.93      0.93     14844
    
    Accuracy : 92.8 %
    Precision : 90.6 %
    Recall : 95.5 %
    F1 Score : 0.93
    Specificity or True Negative Rate : 90.1 %
    Balanced Accuracy : 92.8 %
    MCC : 0.857
    roc_auc_score: 0.928
    


    
![png](output_72_1.png)
    


    -----------------------------------------------------------------------------------------------------
    


```python
#Setting values for the parameters
n_estimators = [100, 300, 500, 800, 1200]
#max_depth = [5, 10, 15, 25, 30]
max_samples = [5, 10, 25, 50, 100]
max_features = [1, 2, 5, 10, 13]
from sklearn.model_selection import RandomizedSearchCV

#Creating a dictionary for the hyper parameters
hyperbag = dict(n_estimators = n_estimators, max_samples = max_samples, 
              max_features = max_features)

#Applying RandomizedSearchCV to get the best value for hyperparameters
Randombag = RandomizedSearchCV(BaggingClassifier(),hyperbag, cv = 3, verbose = 1, n_jobs = -1)
Randombag.fit(x_train, y_train)
```

    Fitting 3 folds for each of 10 candidates, totalling 30 fits
    




<style>#sk-container-id-3 {color: black;background-color: white;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomizedSearchCV(cv=3, estimator=BaggingClassifier(), n_jobs=-1,
                   param_distributions={&#x27;max_features&#x27;: [1, 2, 5, 10, 13],
                                        &#x27;max_samples&#x27;: [5, 10, 25, 50, 100],
                                        &#x27;n_estimators&#x27;: [100, 300, 500, 800,
                                                         1200]},
                   verbose=1)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" ><label for="sk-estimator-id-5" class="sk-toggleable__label sk-toggleable__label-arrow">RandomizedSearchCV</label><div class="sk-toggleable__content"><pre>RandomizedSearchCV(cv=3, estimator=BaggingClassifier(), n_jobs=-1,
                   param_distributions={&#x27;max_features&#x27;: [1, 2, 5, 10, 13],
                                        &#x27;max_samples&#x27;: [5, 10, 25, 50, 100],
                                        &#x27;n_estimators&#x27;: [100, 300, 500, 800,
                                                         1200]},
                   verbose=1)</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" ><label for="sk-estimator-id-6" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: BaggingClassifier</label><div class="sk-toggleable__content"><pre>BaggingClassifier()</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">BaggingClassifier</label><div class="sk-toggleable__content"><pre>BaggingClassifier()</pre></div></div></div></div></div></div></div></div></div></div>




```python
#Printing the best hyperparameters
print('The best hyper parameters are:\n',Randombag.best_params_)
```

    The best hyper parameters are:
     {'n_estimators': 1200, 'max_samples': 100, 'max_features': 1}
    


```python
#Fitting the bagging model with the best hyper parameters obtained through GridSearchCV
bagg1 = BaggingClassifier(max_features=1, max_samples=100,n_estimators= 1200)
bagg1.fit(x_train,y_train)
pred_bagg1 = bagg1.predict(x_test)
```


```python
#Checking different metrics for bagging model after tuning the hyperparameters
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
print('Checking different metrics for bagging model after tuning the hyperparameters:\n')
print("Training accuracy: ",bagg1.score(x_train,y_train))
acc_score = accuracy_score(y_test, pred_bagg1)
print('Testing accuracy: ',acc_score)
conf_mat = confusion_matrix(y_test, pred_bagg1)
print('Confusion Matrix: \n',conf_mat)
roc_auc = roc_auc_score(y_test,pred_bagg1)
print('ROC AUC score: ',roc_auc)
class_rep2 = classification_report(y_test,pred_bagg1)
print('Classification Report: \n',class_rep2)
```

    Checking different metrics for bagging model after tuning the hyperparameters:
    
    Training accuracy:  0.8094051067843427
    Testing accuracy:  0.8084074373484236
    Confusion Matrix: 
     [[5489 1946]
     [ 898 6511]]
    ROC AUC score:  0.8085305109300625
    Classification Report: 
                   precision    recall  f1-score   support
    
               0       0.86      0.74      0.79      7435
               1       0.77      0.88      0.82      7409
    
        accuracy                           0.81     14844
       macro avg       0.81      0.81      0.81     14844
    weighted avg       0.81      0.81      0.81     14844
    
    
CSResults.head(20)

```python
y_pred=ModelET.predict(x_test)
```


```python
y_pred
```




    array([1, 0, 0, ..., 0, 0, 0])




```python
import pandas as pd
Results=pd.DataFrame({'salary_actual':y_test,'salary_predict':y_pred})
ResultsFinal=adult_inc_bk.merge(Results,left_index=True,right_index=True)
ResultsFinal.sample(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>workclass</th>
      <th>fnlwgt</th>
      <th>education</th>
      <th>educational-num</th>
      <th>marital-status</th>
      <th>occupation</th>
      <th>relationship</th>
      <th>race</th>
      <th>gender</th>
      <th>capital-gain</th>
      <th>capital-loss</th>
      <th>hours-per-week</th>
      <th>native-country</th>
      <th>income</th>
      <th>salary_actual</th>
      <th>salary_predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>27536</th>
      <td>30</td>
      <td>Private</td>
      <td>84119</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Married-civ-spouse</td>
      <td>Craft-repair</td>
      <td>Husband</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>2051</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10672</th>
      <td>39</td>
      <td>Local-gov</td>
      <td>20308</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Married-civ-spouse</td>
      <td>Prof-specialty</td>
      <td>Husband</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22509</th>
      <td>24</td>
      <td>Private</td>
      <td>336088</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Divorced</td>
      <td>Exec-managerial</td>
      <td>Not-in-family</td>
      <td>Amer-Indian-Eskimo</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>50</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>23701</th>
      <td>42</td>
      <td>Private</td>
      <td>198096</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Married-civ-spouse</td>
      <td>Other-service</td>
      <td>Husband</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4391</th>
      <td>57</td>
      <td>Private</td>
      <td>367334</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Separated</td>
      <td>Sales</td>
      <td>Unmarried</td>
      <td>White</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>26813</th>
      <td>54</td>
      <td>Private</td>
      <td>101890</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Widowed</td>
      <td>Sales</td>
      <td>Unmarried</td>
      <td>White</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>42728</th>
      <td>23</td>
      <td>Private</td>
      <td>69847</td>
      <td>Bachelors</td>
      <td>13</td>
      <td>Never-married</td>
      <td>Prof-specialty</td>
      <td>Own-child</td>
      <td>Asian-Pac-Islander</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>20</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>46558</th>
      <td>33</td>
      <td>?</td>
      <td>369386</td>
      <td>Some-college</td>
      <td>10</td>
      <td>Married-civ-spouse</td>
      <td>?</td>
      <td>Wife</td>
      <td>White</td>
      <td>Female</td>
      <td>5178</td>
      <td>0</td>
      <td>40</td>
      <td>United-States</td>
      <td>&gt;50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12319</th>
      <td>32</td>
      <td>Private</td>
      <td>240763</td>
      <td>11th</td>
      <td>7</td>
      <td>Divorced</td>
      <td>Transport-moving</td>
      <td>Own-child</td>
      <td>Black</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>United-States</td>
      <td>&lt;=50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>27697</th>
      <td>38</td>
      <td>Federal-gov</td>
      <td>205852</td>
      <td>HS-grad</td>
      <td>9</td>
      <td>Never-married</td>
      <td>Adm-clerical</td>
      <td>Not-in-family</td>
      <td>White</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>United-States</td>
      <td>&gt;50K</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
submission = pd.DataFrame({
    "salary" : y_pred
})
submission.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
submission.to_csv(r"C:\00 DataScience\01-Internship\intern.csv", index = False)
```
# Considering accuracy,ROC_AUC_Score and F1-score we can conclude that RandomForestClassifier is best algorithm for Adult income dataset which gives an accuracy 0f 92.8%